# JARVIS 4.0 — Free-first Android PWA

A GitHub-ready starter for an Android-friendly JARVIS-style assistant. It uses a responsive web interface, animated orb, browser speech input/output where supported, local memory, task-planning templates, and website shortcuts.

## What works without keys or subscriptions

- Installable Progressive Web App (PWA) on supported Android browsers.
- Voice input using the browser Speech Recognition API where available (browser support and network behavior vary).
- Spoken responses using browser speech synthesis.
- Local memory vault stored in this browser's `localStorage`.
- Basic command routing: memory, recall, web search, supported website shortcuts, and a planning template.
- Three local task modules shown as Planner, Research, and Memory.
- Responsive JARVIS-style interface and animated orange orb.

## Important honest limitations

This starter is **not** equivalent to the creator's complete multi-agent desktop system yet.

- A browser PWA cannot silently control every Android app, read the whole phone filesystem, inspect other apps' screens, or execute arbitrary device actions.
- Android requires user-granted permissions and platform-supported APIs. Some actions require a dedicated native Android app and Accessibility/MediaProjection permissions with clear user consent.
- The included “agents” are local workflow modules, not three independent reasoning models.
- The included assistant is a deterministic command router, not a general-purpose LLM. No API key is fabricated or embedded.
- Speech recognition availability depends on browser/device support and may use a browser speech service. It is not guaranteed to work offline.
- The Google Fonts import is optional visual styling; the app itself remains usable if it cannot load.

## Architecture

```text
Android Chrome / installed PWA
        |
        +-- UI: HTML + CSS (animated orb, chat, agent status)
        |
        +-- Voice adapter
        |     +-- SpeechRecognition (if supported)
        |     +-- SpeechSynthesis (if supported)
        |
        +-- Intent router (app.js)
        |     +-- Memory module -> localStorage
        |     +-- Research shortcut -> Google search URL
        |     +-- Planner template -> local response
        |     +-- App shortcuts -> explicit website opening
        |
        +-- Service worker -> static asset cache
```

## Run locally

You need a static web server; opening `index.html` directly may disable microphone and service-worker features.

### GitHub Pages

1. Create a GitHub repository named `jarvis-4-android`.
2. Upload `index.html`, `styles.css`, `app.js`, `manifest.webmanifest`, `sw.js`, and this README to the repository root.
3. In repository **Settings → Pages**, choose **Deploy from a branch**.
4. Select `main` and `/ (root)`, then save.
5. Open the published HTTPS address in Chrome on Android.
6. Use Chrome menu → **Add to Home screen** or **Install app**.
7. Allow microphone permission only when you choose to use voice input.

### Test on a computer

Run any static HTTP server from this folder, then open its local address. For example, with Python installed:

```bash
python -m http.server 8000
```

## Supported starter commands

- `help`
- `remember that my project is called ShadowByte`
- `what do you remember`
- `search the web for black holes`
- `open YouTube`
- `open Gmail`
- `open Calendar`
- `plan my school project`

## Privacy and safety

- Memories are stored in this browser's local storage. Clearing site data can erase them.
- Do not store passwords, API keys, financial credentials, or sensitive personal information in the memory vault.
- Website shortcuts open pages; this app does not sign in or perform account actions for you.
- Review each action before confirming it on the destination website.

## Roadmap for a genuine expanded JARVIS

1. Add an optional local-model bridge to a computer on the same trusted Wi-Fi network (not included in this static PWA).
2. Add a native Android companion for supported app intents and explicitly granted device permissions.
3. Add a user-selected document importer and searchable local knowledge base.
4. Add a real agent orchestrator with task status, cancellation, audit log, and approval before external actions.
5. Add a secure model adapter. Keep provider keys server-side; never put private keys in browser JavaScript or public GitHub.

## License

MIT — see `LICENSE`.
