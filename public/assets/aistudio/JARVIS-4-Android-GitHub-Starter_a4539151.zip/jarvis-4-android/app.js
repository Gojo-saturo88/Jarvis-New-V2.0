const $=id=>document.getElementById(id);
const KEY='jarvis4_memories_v1';
let memories=JSON.parse(localStorage.getItem(KEY)||'[]');
let recognition=null, listening=false;
function save(){localStorage.setItem(KEY,JSON.stringify(memories));renderMemories()}
function renderMemories(){
  $('memoryCount').textContent=memories.length;
  const list=$('memoryList');list.innerHTML='';
  if(!memories.length){list.innerHTML='<p class="muted">Your saved notes stay on this device.</p>';return}
  memories.slice().reverse().forEach((m,revIndex)=>{
    const idx=memories.length-1-revIndex, row=document.createElement('div');row.className='memory-item';
    const span=document.createElement('span');span.textContent=m;
    const del=document.createElement('button');del.textContent='✕';del.setAttribute('aria-label','Delete memory');del.onclick=()=>{memories.splice(idx,1);save()};
    row.append(span,del);list.append(row);
  });
}
function addMessage(text,who='jarvis'){
  const node=document.createElement('div');node.className='message '+(who==='user'?'user':'jarvis');
  const name=document.createElement('b');name.textContent=who==='user'?'YOU':'JARVIS';
  const p=document.createElement('p');p.textContent=text;node.append(name,p);$('chatLog').append(node);$('chatLog').scrollTop=$('chatLog').scrollHeight;
}
function speak(text){
  if(!('speechSynthesis'in window))return;
  speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang=/[\u0900-\u097F]/.test(text)?'hi-IN':'en-IN';u.rate=1; speechSynthesis.speak(u);
}
function reply(text){addMessage(text);speak(text)}
function processCommand(raw){
 const q=raw.trim();if(!q)return;addMessage(q,'user');$('commandInput').value='';
 const s=q.toLowerCase();
 if(/^(stop|stop speaking|quiet|shut up)$/.test(s)){speechSynthesis.cancel();reply('Voice output stopped.');return}
 if(/^(help|what can you do|commands)$/.test(s)){reply('I can save and recall notes, open trusted website shortcuts, search the web, create a task plan, and speak responses. Full device control is not available to a browser-based PWA.');return}
 if(/remember|save (this|that|note)|याद रख|याद रखना/.test(s)){
   const note=q.replace(/^(jarvis[, ]*)?/i,'').replace(/remember that|remember|save this|save that|save note|याद रखो|याद रखना/ig,'').trim();
   if(note){memories.push(note);save();reply('Saved in your local Memory Vault.');}else reply('Tell me what you would like me to remember.');return;
 }
 if(/what do you remember|recall|my memories|क्या याद/.test(s)){reply(memories.length?'Here is what I remember:\n'+memories.map((m,i)=>(i+1)+'. '+m).join('\n'):'Your memory vault is empty.');return}
 if(/search|google|web|internet|खोज/.test(s)){const term=q.replace(/^(jarvis[, ]*)?/i,'').replace(/search (the )?(web )?(for )?|google |look up /ig,'').trim();window.open('https://www.google.com/search?q='+encodeURIComponent(term||q),'_blank','noopener');reply('I opened a web search for: '+(term||q));return}
 if(/open (youtube|यूट्यूब)/.test(s)){window.open('https://www.youtube.com','_blank','noopener');reply('Opening YouTube.');return}
 if(/open (gmail|mail)/.test(s)){window.open('https://mail.google.com','_blank','noopener');reply('Opening Gmail.');return}
 if(/open (calendar)/.test(s)){window.open('https://calendar.google.com','_blank','noopener');reply('Opening Google Calendar.');return}
 if(/plan|steps|organize|योजना/.test(s)){reply('Planner agent draft:\n1. Define the exact outcome.\n2. Break it into small tasks.\n3. Gather the files or information needed.\n4. Complete one step at a time.\n5. Review the result before sharing or publishing.\nTell me the goal and I can make this checklist more specific.');return}
 if(/hello|hi jarvis|hey jarvis|नमस्ते|हेलो/.test(s)){reply('Hello. JARVIS is online. How may I help?');return}
 reply('I can handle local memory, basic commands and web shortcuts without an API key. For open-ended AI reasoning, this free offline starter needs a compatible local model or an optional AI provider; I will not pretend a fixed command engine is a full language model. Try “help” to see supported commands.');
}
$('sendBtn').onclick=()=>processCommand($('commandInput').value);
$('commandInput').addEventListener('keydown',e=>{if(e.key==='Enter')processCommand($('commandInput').value)});
$('memoryForm').onsubmit=e=>{e.preventDefault();const v=$('memoryInput').value.trim();if(v){memories.push(v);save();$('memoryInput').value='';}};
$('clearBtn').onclick=()=>{$('chatLog').innerHTML='';addMessage('Chat cleared. Your saved memories are unchanged.')};
$('stopBtn').onclick=()=>speechSynthesis?.cancel();
$('micBtn').onclick=()=>{
 const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!SR){reply('Speech recognition is not available in this browser. Try Chrome on Android or type your command.');return}
 if(listening){recognition.stop();return}
 recognition=new SR();recognition.lang='en-IN';recognition.interimResults=false;recognition.maxAlternatives=1;
 recognition.onstart=()=>{listening=true;$('voiceState').textContent='LISTENING';$('micBtn').innerHTML='🎙 Listening…'};
 recognition.onresult=e=>processCommand(e.results[0][0].transcript);
 recognition.onerror=()=>{reply('I could not hear that clearly. You can type the command instead.');};
 recognition.onend=()=>{listening=false;$('voiceState').textContent='STANDBY';$('micBtn').innerHTML='🎙 Voice'};
 recognition.start();
};
document.querySelectorAll('[data-url]').forEach(b=>b.onclick=()=>window.open(b.dataset.url,'_blank','noopener'));
renderMemories();